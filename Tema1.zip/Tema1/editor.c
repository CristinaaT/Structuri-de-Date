#include <stdio.h>
#include <stdlib.h>

#define MODE_INSERT 0
#define MODE_COMMAND 1

#define COMMAND_NOTHING 0
#define COMMAND_INSERT 1
#define COMMAND_B 2
#define COMMAND_DL 3
#define COMMAND_D 4
#define COMMAND_GL 5
#define COMMAND_GC 6

typedef struct char_t {
    char c;
    struct char_t *prev;
    struct char_t *next;
} char_t;

typedef struct line_t {
    char_t *p_sentinel;
    struct line_t *prev;
    struct line_t *next;   
} line_t;

typedef struct cursor_t {
    line_t *p_first;    //Prima linie din editor
    line_t *p_line;     //Linia curenta
    char_t *p_char;     //Caracterul curent
} cursor_t;

typedef struct command_t {
	int type;          //Tipul comenzii
	line_t *command;   //Inputul dat pentru efectuarea comenzii respective
	line_t *text;      //Textul sters de comanda respectiva
	int x, y;          //Eventuali parametrii ai comenzii inverse
} command_t;

//Lista de comenzi
typedef struct log_t {
	command_t *p_command;
	struct log_t *prev;
	struct log_t *next;
} log_t;

//Functii pentru char_t 
char_t *make_char(char c)
{
    char_t *p = malloc(sizeof(char_t));
    p->c = c;
    p->prev = NULL;
    p->next = NULL;
    return p;
}

void free_char(char_t *p_char)
{
	if (p_char == NULL) 
		return;
    free(p_char);
}

void insert_char_after(char_t *p_char, char c)
{
    char_t *p = p_char->next;
    p_char->next = make_char(c);
    p_char->next->prev = p_char;
    p_char->next->next = p;
    if (p != NULL) 
    	p->prev = p_char->next;
}

void remove_char(char_t *p_char)
{
    if (p_char->next != NULL) {
        p_char->next->prev = p_char->prev;
    }
    if (p_char->prev != NULL) {
        p_char->prev->next = p_char->next;
    }
    free(p_char);
}

//Functii pentru line_t
line_t *make_line()
{
    line_t *p = malloc(sizeof(line_t));
    p->p_sentinel = make_char('\0');
    p->prev = NULL;
    p->next = NULL;
    return p;
}

void free_line(line_t *p_line)
{
	if(p_line == NULL) return;
    char_t *p = p_line->p_sentinel;
    while (p) {
        char_t *tmp = p->next;
        free_char(p);
        p = tmp;
    }
    free(p_line);
}

int get_line_length(line_t *p_line)
{
	int l = 0;
	char_t *p = p_line->p_sentinel;
	while (p->next) {
		++l;
		p = p->next;
	}
	return l;
}

//Rezultatul este negativ daca apare o eroare la citire (sau EOF)
int read_line(FILE *f, line_t *p_line)
{
    char c;
    int e = 0;
    char_t *p = p_line->p_sentinel;
    while ((e = fscanf(f, "%c", &c)) > 0) {
        if (c == '\n') break;
        insert_char_after(p, c);
        p = p->next;
    }
    return e;
}

//Daca nu exista, atunci vor avea valoarea 1
void parse_integers(line_t *p_line, int *x, int *y)
{
    *x = *y = -1;
    char_t *p = p_line->p_sentinel->next;
    while (p && !('0' <= p->c && p->c <= '9')) p = p->next;
    if (p) {
        *x = 0;
        while (p && '0' <= p->c && p->c <= '9') {
            *x = (*x) * 10 + p->c - '0';
            p = p->next;
        }
    }
    while (p && !('0' <= p->c && p->c <= '9')) p = p->next;
    if (p) {
        *y = 0;
        while (p && '0' <= p->c && p->c <= '9') {
            *y = (*y) * 10 + p->c - '0';
            p = p->next;
        }
    }
}

//Returneaza 0 daca sirul s este egal cu p_line
int compare_line(line_t *p_line, char *s)
{
    char_t *p = p_line->p_sentinel->next;
    int i = 0;
    while (s[i] != '\0' && p) {
        if (p->c != s[i]) {
            return p->c - s[i];
        }
        ++i;
        p = p->next;
    }
    if (p == NULL && s[i] != '\0') return -1;
    return 0;
}

char_t *get_last_char(line_t *p_line) {
    char_t *p = p_line->p_sentinel;
    while (p->next) p = p->next;
    return p;
}

//Functii pentru cursor_t
cursor_t *make_cursor()
{
    cursor_t *p = malloc(sizeof(cursor_t));
    p->p_line = make_line();
    p->p_first = p->p_line;
    p->p_char = p->p_first->p_sentinel;
    return p;
}

void free_cursor(cursor_t *p_cursor)
{
    line_t *p = p_cursor->p_first;
    while (p) {
        line_t *tmp = p->next;
        free_line(p);
        p = tmp;
    }
    free(p_cursor);
}

//Obtine numarul liniei si al pozitiei caracterului curent
void get_cursor_position(cursor_t *p_cursor, int *k, int *line)
{
	int x = 0, y = 1;
	char_t *p1 = p_cursor->p_char;
	line_t *p2 = p_cursor->p_line;
	while (p1->prev) {
		p1 = p1->prev;
		++x;
	}
	while (p2->prev) {
		p2 = p2->prev;
		++y;
	}
	*k = x;
	*line = y;
}

//Functii pentru comenzile dorite

//Insereaza o linie (fara newline) prin copiere
void insert_line(cursor_t *p_cursor, line_t *p_line)
{
	char_t *p = p_line->p_sentinel->next;
	while (p) {
		insert_char_after(p_cursor->p_char, p->c);
		p_cursor->p_char = p_cursor->p_char->next;
		p = p->next;
	}
}

void insert_newline(cursor_t *p_cursor)
{
	line_t *tmp1 = make_line();
	tmp1->next = p_cursor->p_line->next;
	tmp1->prev = p_cursor->p_line;
	p_cursor->p_line->next = tmp1;
	if (tmp1->next != NULL) tmp1->next->prev = tmp1;
	p_cursor->p_line = tmp1;
	tmp1->p_sentinel->next = p_cursor->p_char->next;
	if (p_cursor->p_char->next != NULL) {
		p_cursor->p_char->next->prev = tmp1->p_sentinel;
	}
	p_cursor->p_char->next = NULL;
	p_cursor->p_char = tmp1->p_sentinel;
}

void save(char *file_name, cursor_t *p_cursor)
{
    FILE *f = fopen(file_name, "wt");
    if (f == NULL) {
        fprintf(stderr, "Eroare la deschiderea fisierului de salvare!\n");
        return;
    }
    line_t *p_line = p_cursor->p_first;
    while (p_line) {
        char_t *p = p_line->p_sentinel->next;
        while (p) {
            fprintf(f, "%c", p->c);
            p = p->next;
        }
        p_line = p_line->next;
        if (p_line) fprintf(f, "\n");
    }
    fclose(f);
}

char backspace(cursor_t *p_cursor)
{
	char c = 0;
    if (p_cursor->p_char != p_cursor->p_line->p_sentinel) {
        char_t *tmp = p_cursor->p_char;
        p_cursor->p_char = tmp->prev;
		c = tmp->c;
        remove_char(tmp);
    } else if (p_cursor->p_line != p_cursor->p_first) {
		c = '\n';
        line_t *tmp = p_cursor->p_line;
        
        //Muta cursorul la ultima pozitie pe linia precedenta
        p_cursor->p_line = tmp->prev;
        p_cursor->p_char = get_last_char(p_cursor->p_line);

        //Concateneaza textul
        p_cursor->p_char->next = tmp->p_sentinel->next;
        if (tmp->p_sentinel->next != NULL) {
            tmp->p_sentinel->next->prev = p_cursor->p_char;
        }

        //Corecteaza liniile
        p_cursor->p_line->next = tmp->next;
        if (tmp->next != NULL) {
            tmp->next->prev = p_cursor->p_line;
        }

        //Elibereaza memoria nefolosita
        tmp->p_sentinel->next = NULL;
        free_line(tmp);
    }
	return c;
}

//k=-1 pt linia curenta
line_t *delete_line(cursor_t *p_cursor, int k)
{
    line_t *p = NULL;   //Linia care trebuie stearsa
    if (k==-1) {
        p = p_cursor->p_line;
    } else {
        p = p_cursor->p_first;
        int i = 1;
        while (p->next && i < k) {
            ++i;
            p = p->next;
        }
    }

    //Repozitionare cursor, daca este cazul
    if (p == p_cursor->p_line) {
        if (p_cursor->p_line != p_cursor->p_first) {
            p_cursor->p_line = p_cursor->p_line->prev;
        } else if (p_cursor->p_line->next != NULL) { //Sterge prima
            p_cursor->p_line = p_cursor->p_line->next;
            p_cursor->p_first = p_cursor->p_line;   //Noua prima linie
            p_cursor->p_line->prev = NULL;
            return p;
        } else { //Sterge singura linie
            p = p_cursor->p_line;
            p_cursor->p_line = make_line();
            p_cursor->p_first = p_cursor->p_line;
            p_cursor->p_char = p_cursor->p_line->p_sentinel;
			return p;
        }
        p_cursor->p_char = p_cursor->p_line->p_sentinel;
    }

    //Stabilire conexiuni intre linii dupa delete
    if (p == p_cursor->p_first) {
        p_cursor->p_first = p->next;
        p->next->prev = NULL;
    } else {
        if (p->next != NULL) {
            p->prev->next = p->next;
            p->next->prev = p->prev;
        } else { //Daca e ultima linie adaugam inca o linie tip "newline"
            p->prev->next = make_line();
            p->prev->next->prev = p->prev;
        }
    }

    return p;
}

line_t *delete_chars(int k, cursor_t *p_cursor)
{
	line_t *ans = make_line();
	char_t *aux = ans->p_sentinel;
    char_t *p = p_cursor->p_char;
    while (k && p->next) {
        char_t *tmp = p->next;
        p->next = p->next->next;
        if (p->next != NULL) p->next->prev = p;
		insert_char_after(aux, tmp->c);
		aux = aux->next;
        free_char(tmp);
        --k;
    }
	return ans;
}

void goto_line(cursor_t *p_cursor, int k)
{
    p_cursor->p_line = p_cursor->p_first;
    int i = 1;
    while (i < k && p_cursor->p_line->next) {
        p_cursor->p_line = p_cursor->p_line->next;
        ++i;
    }
    p_cursor->p_char = p_cursor->p_line->p_sentinel;
}

void goto_char(cursor_t *p_cursor, int k_char, int k_line)
{
    if (k_line > 0) goto_line(p_cursor, k_line);    //Daca k_line=-1, atunci ramane pe linia curenta
    p_cursor->p_char = p_cursor->p_line->p_sentinel;
    int i = 1;
    while (i < k_char && p_cursor->p_char->next) {
        p_cursor->p_char = p_cursor->p_char->next;
        ++i;
    }
}

log_t *make_log(int type, line_t *command, line_t *text, int x, int y)
{
	log_t *p = malloc(sizeof(log_t));
	p->p_command = malloc(sizeof(command_t));
	p->p_command->type = type;
	p->p_command->command = command;
	p->p_command->text = text;
	p->p_command->x = x;
	p->p_command->y = y;
	p->next = NULL;
	p->prev = NULL;
	return p;
}

void free_log(log_t *p)
{
	free_line(p->p_command->command);
	free_line(p->p_command->text);
	free(p->p_command);
	free(p);
}

void free_multilog(log_t *p)
{
	while (p) {
		log_t *tmp = p->prev;
		free_log(p);
		p = tmp;
	}
}

int main(int argc, char **argv)
{
    if (argc!= 2) {
        fprintf(stderr, "Prea multe sau prea putine argumente!\n");
        return -1;
    }

    int mode = MODE_INSERT;
    int e;  //Verifica daca citirea s-a terminat
    int save_counter = 0;
    cursor_t *editor = make_cursor();
	log_t *undo = make_log(COMMAND_NOTHING, NULL, NULL, -1, -1);
	log_t *redo = make_log(COMMAND_NOTHING, NULL, NULL, -1, -1);
    do {
        line_t *buffer = make_line();
        e = read_line(stdin, buffer);
        if (buffer->p_sentinel->next != NULL && 
            compare_line(buffer, "::i") == 0) { //Schimba modul de functionare
            if (mode == MODE_INSERT) mode = MODE_COMMAND;
            else if (mode == MODE_COMMAND) mode = MODE_INSERT;
            else fprintf(stderr, "Editorul este intr-un mod invalid!\n");
            free_line(buffer);
            continue;
        }
        if (mode == MODE_COMMAND) {
            ++save_counter;
            if (compare_line(buffer, "u") == 0) {
				int k1, k2;	
            	switch (undo->p_command->type) {
				case COMMAND_INSERT:
					while (undo->prev->p_command->type == COMMAND_INSERT) {
						backspace(editor);    //Delete newline
						k2 = get_line_length(undo->p_command->command);
						for (k1 = 0; k1 < k2; ++k1) backspace(editor);
						undo = undo->prev;
						undo->next->next = NULL;
						undo->next->prev = redo;
						redo->next = undo->next;
						redo = undo->next;
						undo->next = NULL;
					}
					backspace(editor);         //Delete newline
					k2 = get_line_length(undo->p_command->command);
					for (k1 = 0; k1 < k2; ++k1) backspace(editor);
					break;
				case COMMAND_B:
					if (undo->p_command->text->p_sentinel->next->c == '\n') {
						insert_newline(editor);
					} else {
						insert_line(editor, undo->p_command->text);
					}
					break;
				case COMMAND_DL:
					parse_integers(undo->p_command->command, &k1, &k2);
					if (k1 != -1) goto_line(editor, k1);
					else goto_line(editor, undo->p_command->y);
					insert_line(editor, undo->p_command->text);
					insert_newline(editor);
					goto_char(editor, undo->p_command->x, undo->p_command->y);
					break;
				case COMMAND_D:
					parse_integers(undo->p_command->command, &k1, &k2);
					insert_line(editor, undo->p_command->text);
					goto_char(editor, undo->p_command->x, undo->p_command->y);
					break;
				case COMMAND_GL:
					goto_char(editor, undo->p_command->x, undo->p_command->y);
					break;
				case COMMAND_GC:
					goto_char(editor, undo->p_command->x, undo->p_command->y);
					break;
				}
				if (undo->p_command->type != COMMAND_NOTHING) {
					undo = undo->prev;
					undo->next->next = NULL;
					undo->next->prev = redo;
					redo->next = undo->next;
					redo = undo->next;
					undo->next = NULL;
				}
            } else if (compare_line(buffer, "r") == 0) {
				if (redo->p_command->type == COMMAND_INSERT) {
					while (redo->p_command->type == COMMAND_INSERT) {
						insert_line(editor, redo->p_command->command);
						insert_newline(editor);
						undo->next = make_log(COMMAND_INSERT,
									   redo->p_command->command, NULL, -1, -1);
						undo->next->prev = undo;
						undo = undo->next;
						free_line(redo->p_command->text);
						free(redo->p_command);
						redo = redo->prev;
						free(redo->next);
						redo->next = NULL;
					}
				} else if (redo->p_command->type != COMMAND_NOTHING) {
					free_line(buffer);
					buffer = redo->p_command->command;
					free_line(redo->p_command->text);
					free(redo->p_command);
					redo = redo->prev;
					free(redo->next);
					redo->next = NULL;
				}
            }
			if (compare_line(buffer, "s") == 0) {
                --save_counter;
                save(argv[1], editor);
				free_line(buffer);
            } else if (compare_line(buffer, "q") == 0) {
                free_line(buffer);
                free_cursor(editor);
				free_multilog(undo);
				free_multilog(redo);
                return 0;
            } else if (compare_line(buffer, "b") == 0) {
                char c = backspace(editor);
				line_t *tmp = make_line();
				insert_char_after(tmp->p_sentinel, c);
				undo->next = make_log(COMMAND_B, buffer, tmp, -1, -1);
				undo->next->prev = undo;
				undo = undo->next;
            } else if (compare_line(buffer, "dl") == 0) {
                int x, y;
				get_cursor_position(editor, &x, &y);
				undo->next = make_log(COMMAND_DL, buffer, NULL, x, y);
				undo->next->prev = undo;
				undo = undo->next;

                parse_integers(buffer, &x, &y);
                undo->p_command->text = delete_line(editor, x);
            } else if (compare_line(buffer, "d") == 0) {
                int x, y;
				get_cursor_position(editor, &x, &y);
				undo->next = make_log(COMMAND_D, buffer, NULL, x, y);
				undo->next->prev = undo;
				undo = undo->next;

                parse_integers(buffer, &x, &y);
                if (x == -1) x = 1;
                undo->p_command->text = delete_chars(x, editor);
            } else if (compare_line(buffer, "gl") == 0) {
                int x, y;
				get_cursor_position(editor, &x, &y);
				undo->next = make_log(COMMAND_GL, buffer, NULL, x, y);
				undo->next->prev = undo;
				undo = undo->next;

                parse_integers(buffer, &x, &y);
                goto_line(editor, x);
            } else if (compare_line(buffer, "gc") == 0) {
                int x, y;
				get_cursor_position(editor, &x, &y);
				undo->next = make_log(COMMAND_GL, buffer, NULL, x, y);
				undo->next->prev = undo;
				undo = undo->next;

                parse_integers(buffer, &x, &y);
                goto_char(editor, x, y);
            } else free_line(buffer);
            if (save_counter == 5) {
                save_counter = 0;
                save(argv[1], editor);
            }
        } else if (mode == MODE_INSERT) {
            //Adauga buffer-ul in editor la pozitia cursorului
			insert_line(editor, buffer);
			insert_newline(editor);
			undo->next = make_log(COMMAND_INSERT, buffer, NULL, -1, -1);
			undo->next->prev = undo;
			undo = undo->next;
        }
    } while (e > 0);
    free_cursor(editor);
	free_multilog(undo);
	free_multilog(redo);
    return 0;
}